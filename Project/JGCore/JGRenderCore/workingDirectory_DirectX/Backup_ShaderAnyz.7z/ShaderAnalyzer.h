#pragma once
#include"Common/JGRCCommon.h"
#include"DirectXCommon.h"
#include"MaterialSystem/Shader/ShaderTool/ShaderObject.h"

namespace JGRC
{
	// enum class EShaderType;
	class CORE_EXPORT ShaderAnalyzer
	{
	private:
		class AyzInformation
		{
		public:
			std::string hlslPath;
			std::unique_ptr<class LayoutInformation>  InputLayout;
			std::unique_ptr<class CBufferInformation> CBuffer;
			std::unique_ptr<class SamplerInformation> SamplerState;
			std::unique_ptr<class TextureInformation> Texture;
			AyzInformation();
			AyzInformation(AyzInformation&& copy);
		};
	private:
		class JGBufferManager* m_BufferMG;
		class DirectX*         m_DirectX;
	private:
		std::map<EShaderType, AyzInformation> m_mInformation;
		// hlsl path
		// �Է� ���̾ƿ�����
		// ��� ����

		

		std::unique_ptr<class LayoutInformation>  m_InputLayoutInfor;
		std::unique_ptr<class CBufferInformation> m_CBufferInfor;
		std::unique_ptr<class SamplerInformation> m_SamplerInfor;
		std::unique_ptr<class TextureInformation> m_TextureInfor;
		std::string m_ShaderPath;
		EShaderType m_ShaderType;
		bool m_bIgnore = false;

		// �ӽ�
		std::vector<class JGBuffer*> m_vBuffers;
	public:
		ShaderAnalyzer();
		~ShaderAnalyzer();

		bool Analyze(const std::string& hlslPath, const EShaderType ShaderType);
		bool Analyze_tmp(const std::string& hlslPath, const EShaderType ShaderType);
		bool OutputShaderData(const std::string& name);





		// �̰͵� 
		void CreateConstantBuffers();
		void WriteConstantBuffers();
		/*
		Exp : �Է� ���̾ƿ� �迭�� ����ϴ�. */
		// �̰� ���߿� ���͸��� �ý��ۿ��� �ٷ� �� �ӽ� �Լ�..
		void MakeInputLayoutArray(class InputLayout* ly);
		float*   GetParam(const std::string& paramName);
		void     SetParam(const std::string& paramName, void* value);
		uint     GetParamSize(const std::string& paramName);
	private:
		bool RemoveRemark(std::string& sentence);
		std::string IncludeAyz(std::string hlslPath, std::string& sentence);
	};
}
